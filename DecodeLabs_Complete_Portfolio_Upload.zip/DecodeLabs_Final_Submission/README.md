# DecodeLabs Data Analytics Portfolio

Prepared by: Ezekiel Adewole

## Contents
- `reports/DECODELABS_DATA_ANALYTICS_PORTFOLIO.docx` — consolidated report covering Projects 1–4 and stating the evidence status.
- `data/DECODELAB.xlsx` — source workbook with `MESSY` and `DATA CLEANING` worksheets.
- `data/DECODELAB_Analysis_EDA_DV.xlsx` — analysis workbook with `MESSY`, `DATA CLEANING`, `EDA`, and `DV` worksheets.
- `sql/sales_analysis.sql` — prepared SQLite queries for Project 3.

## Important SQL status
The SQL script is prepared, but execution has not been verified from the supplied materials. Import the cleaned worksheet as a SQLite table named `sales`, preserve the column names, run the queries, and retain result screenshots or exports before claiming SQL execution is complete.

## Dataset
1,200 records and 14 fields. The report records the statistics present in the supplied EDA worksheet. For 2025, the available data ends on 30 June, so its annual total is a six-month total.
