/*
DecodeLabs Data Analytics - Project 3: SQL Data Analysis
Dataset: DECODELAB.xlsx, DATA CLEANING worksheet
SQLite table: sales

Before running:
1. Import the DATA CLEANING worksheet as a table named sales.
2. Preserve the column names exactly as shown in the workbook.
3. Run the queries in order or individually.
*/

-- 1. Preview the dataset
SELECT *
FROM sales
LIMIT 10;

-- 2. Count the total number of records
SELECT COUNT(*) AS total_records
FROM sales;

-- 3. Select relevant order details
SELECT
    "ORDER ID",
    "DATE",
    "PRODUCT",
    "QUANTITY",
    "TOTAL PRICE",
    "ORDER STATUS"
FROM sales
LIMIT 20;

-- 4. Filter completed orders (Delivered or Shipped)
SELECT *
FROM sales
WHERE "ORDER STATUS" IN ('Delivered', 'Shipped')
ORDER BY "DATE" DESC;

-- 5. Sort orders by total price, highest first
SELECT
    "ORDER ID",
    "PRODUCT",
    "QUANTITY",
    "TOTAL PRICE"
FROM sales
ORDER BY CAST("TOTAL PRICE" AS REAL) DESC
LIMIT 20;

-- 6. Count orders by product
SELECT
    "PRODUCT",
    COUNT(*) AS order_count
FROM sales
GROUP BY "PRODUCT"
ORDER BY order_count DESC;

-- 7. Calculate sales value and average order value
SELECT
    SUM(CAST("TOTAL PRICE" AS REAL)) AS total_sales_value,
    AVG(CAST("TOTAL PRICE" AS REAL)) AS average_order_value
FROM sales;

-- 8. Calculate total quantity and average unit price by product
SELECT
    "PRODUCT",
    SUM(CAST("QUANTITY" AS INTEGER)) AS units_ordered,
    AVG(CAST("UNIT PRICE" AS REAL)) AS average_unit_price
FROM sales
GROUP BY "PRODUCT"
ORDER BY units_ordered DESC;

-- 9. Examine order status distribution
SELECT
    "ORDER STATUS",
    COUNT(*) AS number_of_orders
FROM sales
GROUP BY "ORDER STATUS"
ORDER BY number_of_orders DESC;

-- 10. Compare payment methods
SELECT
    "PAYMENT METHOD",
    COUNT(*) AS transaction_count,
    SUM(CAST("TOTAL PRICE" AS REAL)) AS sales_value
FROM sales
GROUP BY "PAYMENT METHOD"
ORDER BY sales_value DESC;

-- 11. Examine referral sources
SELECT
    "REFERRAL SOURCE",
    COUNT(*) AS order_count
FROM sales
GROUP BY "REFERRAL SOURCE"
ORDER BY order_count DESC;

-- 12. Monthly sales trend
SELECT
    strftime('%Y-%m', "DATE") AS sales_month,
    COUNT(*) AS order_count,
    SUM(CAST("TOTAL PRICE" AS REAL)) AS monthly_sales
FROM sales
GROUP BY strftime('%Y-%m', "DATE")
ORDER BY sales_month;
